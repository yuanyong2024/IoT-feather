## Release History
**[QPY_OCPU_V0002_BG95M3_FW] 2024-03-05**
* ZH
1. 修改helios spi的读写接口为阻塞式

* EN
1. Example Change the read/write interface of the helios spi to blocking



**[QPY_OCPU_V0001_BG95M3_FW] 2023-12-18**
* ZH
* 支持功能list
1. app_fota
2. atcmd
3. dataCall
4. fota
5. log
6. net
7. ntptime
8. pm
9. queue
10. sim
11. sysbus
12. uio
13. ujson
14. umqtt
15. usocket
16. utime
17. _thread
18. Timer
19. RTC
20. WDT
21. Pin
22. ExtInt
23. UART
24. SPI
25. IIC
26. Power
27. ADC
28. PowerKey
29. PWM
30. quecgnss
31. ussl


* EN
* Support function list
1. app_fota
2. atcmd
3. dataCall
4. fota
5. log
6. net
7. ntptime
8. pm
9. queue
10. sim
11. sysbus
12. uio
13. ujson
14. umqtt
15. usocket
16. utime
17. _thread
18. Timer
19. RTC
20. WDT
21. Pin
22. ExtInt
23. UART
24. SPI
25. IIC
26. Power
27. ADC
28. PowerKey
29. PWM
30. quecgnss
31. ussl